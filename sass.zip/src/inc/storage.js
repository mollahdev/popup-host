const STORAGE = new Map();

export default function stroage() {
    return STORAGE;
}